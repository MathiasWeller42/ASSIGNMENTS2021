#/bin/sh
cp rescue/dunefiles/src.compiler.dune src/compiler/dune
cp rescue/dunefiles/src.compiler.main.dune src/compiler/main/dune
rm -f CONFIGURED-RESCUE
touch CONFIGURED-NORM
