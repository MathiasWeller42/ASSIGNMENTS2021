#!/bin/sh 
_build/install/default/bin/tigerc "$@" 2>&1
exit $?